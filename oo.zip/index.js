const Discord = require("discord.js-selfbot-v13");
const client = new Discord.Client({
  intents: [
    Discord.Intents.FLAGS.GUILDS,
    Discord.Intents.FLAGS.GUILD_VOICE_STATES
  ],
  checkUpdate: false,
});
const fs = require('fs');
const Enmap = require('enmap');
const utils = require('./utils');
const { Player } = require("discord-player");
const logChannelId = '1240780333826445372'; // Replace with your desired channel ID
// Require the config.js file
const config = require('./config.js');

// Access the prefix property
const prefix = config && config.prefix ? config.prefix : "$";

// Now you can use the prefix variable as needed
console.log("Prefix:", prefix);

// Function to generate the table with emojis
function generateTableWithEmojis(loaded, client) {
  let table = '```\n'; // Start Markdown code block
  table += 'Table of commands and events:\n';
  table += '---------------------------------\n';
  table += 'Commands:\n';
  loaded.commands.forEach(cmd => {
    table += `${cmd} ${client.commands.has(cmd) ? '✅' : '❌'}\n`; // Check if command exists
  });
  table += '---------------------------------\n';
  table += 'Events:\n';
  loaded.events.forEach(evt => {
    table += `${evt} ${client.listenerCount(evt) > 0 ? '✅' : '❌'}\n`; // Check if event has listeners
  });
  table += '```'; // End Markdown code block
  return table;
}

// Function to send errors to the specified channel
function sendErrorToChannel(error) {
  const errorChannel = client.channels.cache.get(logChannelId);
  if (errorChannel) {
    errorChannel.send(`An error occurred:\n\`\`\`js\n${error.stack}\`\`\``)
      .catch(console.error);
  } else {
    console.error(`Error channel ${logChannelId} not found.`);
  }
}

// Handle unhandled promise rejections
process.on('unhandledRejection', error => {
  console.error('Unhandled promise rejection:', error);
  sendErrorToChannel(error);
});

// Handle uncaught exceptions
process.on('uncaughtException', error => {
  console.error('Uncaught exception:', error);
  sendErrorToChannel(error);
});

// Handle Discord client errors
client.on('error', error => {
  console.error('Discord client error:', error);
  sendErrorToChannel(error);
});

if (!process.env.TOKEN){
  try{
    const config = require("./config");
    global.config = {'token': config.token, 'prefix': config.prefix};
  } catch (e){
    console.error("No config file found, create it or use environment variables.");
    process.exit(1);
  };
} else{
  if (!process.env.PREFIX) process.env.PREFIX="$";
  global.config = {'token': process.env.TOKEN, 'prefix': process.env.PREFIX};
}

if (!process.env.ALLOWED){
  try {
    global.config.allowed=require("./allowed.json").allowed
  } catch (e){
    global.config.allowed=[]
  }
} else{
  global.config.allowed=process.env.ALLOWED
}

client.login(config.token);

utils.log("Logging in...");

/* ----------------------------------------------- */

global.queue = new Map();
client.commands = new Enmap();

client.player = new Player(client, {
  ytdlOptions: {
      quality: "highestaudio",
      highWaterMark: 1 << 25
  }
});

/* ----------------------------------------------- */

var loaded = {events: [], commands: []};

var promise = new Promise((resolve) => {
  fs.readdir('./events/', (err, files) => {
    if (err) {
      sendErrorToChannel(err);
      return console.error(err);
    }
    files.forEach(file => {
      if (!file.endsWith('.js')) return;
      const evt = require(`./events/${file}`);
      let evtName = file.split('.')[0];
      loaded.events.push(evtName);
      client.on(evtName, evt.bind(null, client));
    });
    resolve();
  });
});

fs.readdir('./commands/', async (err, files) => {
  if (err) {
    sendErrorToChannel(err);
    return console.error(err);
  }
  files.forEach(file => {
    if (!file.endsWith('.js')) return;
    let props = require(`./commands/${file}`);
    if (!props.names || !props.names.list) {
      sendErrorToChannel(new Error(`Invalid command file structure: ${file}`));
      return console.error("Invalid command file structure:", file);
    }
    
    props.names.list.forEach(name => {
      client.commands.set(name, props);
    });
    let cmdName = file.split('.')[0];
    loaded.commands.push(cmdName);
  });
  promise.then(() => {
    const tableMessage = `\`\`\`Table of commands and events:\n${generateTableWithEmojis(loaded, client)}\`\`\``;
    utils.log(tableMessage);

    // Get the text channel where you want to send the table log
    const logChannel = client.channels.cache.get(logChannelId);
    if (logChannel) {
      const embed = new Discord.MessageEmbed()
        .setTitle("Table of Commands and Events")
        .setDescription(generateTableWithEmojis(loaded, client))
        .setColor("#7289da") // Optional: set a color for the embed
        .setTimestamp();

      logChannel.send({ embeds: [embed] })
        .catch(error => sendErrorToChannel(error));
    } else {
      console.error(`Log channel ${logChannelId} not found.`);
    }
  });
});

/* ----------------------------------------------- */

// Command to add or remove ID from allowed.json
client.on('message', message => {
  const prefix = config.prefix;
  if (message.author.id === '520774569855025152') {
    if (message.content.startsWith(`${prefix}setadmin`)) {
      const mentionedUser = message.mentions.users.first();
      if (!mentionedUser) {
        message.channel.send('Invalid command usage. Mention a user to add. Use: `*admin @user`');
        return;
      }
      const userId = mentionedUser.id;
      global.config.allowed.push(userId);
      fs.writeFile('./allowed.json', JSON.stringify({allowed: global.config.allowed}), (err) => {
        if (err) {
          console.error('Error writing to allowed.json:', err);
          sendErrorToChannel(err);
          return;
        }
        message.channel.send(`User ${mentionedUser} has been added to allowed`);
      });
    } else if (message.content.startsWith(`${prefix}unadmin`)) {
      const mentionedUser = message.mentions.users.first();
      if (!mentionedUser) {
        message.channel.send('Invalid command usage. Mention a user to remove. Use: `*unadmin @user`');
        return;
      }
      const userId = mentionedUser.id;
      const index = global.config.allowed.indexOf(userId);
      if (index === -1) {
        message.channel.send(`User ${mentionedUser} is not in allowed`);
        return;
      }
      global.config.allowed.splice(index, 1);
      fs.writeFile('./allowed.json', JSON.stringify({allowed: global.config.allowed}), (err) => {
        if (err) {
          console.error('Error writing to allowed.json:', err);
          sendErrorToChannel(err);
          return;
        }
        message.channel.send(`User ${mentionedUser} has been removed from allowed`);
      });
    } else if (message.content.startsWith(`${prefix}list`)) {
      const allowedUsers = global.config.allowed.map(userId => {
          const user = client.users.cache.get(userId);
          return user ? `<@${userId}>` : `Unknown User (${userId})`;
      });
      message.channel.send(`List of allowed users:\n${allowedUsers.join('\n')}`);
  }  
  }
});

client.on('message', message => {
  const prefix = config.prefix;
//if (message.author.id === '520774569855025152')
  if (!message.content.startsWith(prefix) || !message.author.id === '520774569855025152') return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'addr') {
    const word = args[0];
    if (!word) {
      message.channel.send('Please provide a word to set a replay for.');
      return;
    }

    message.channel.send(`Please reply with the replay for the word "${word}" within 15 seconds.`);

    const filter = m => m.author.id === message.author.id;
    message.channel.awaitMessages({ filter, max: 1, time: 15000, errors: ['time'] })
      .then(collected => {
        const replay = collected.first().content;
        saveReplay(word, replay);
        message.channel.send(`Replay for the word "${word}" has been set.`);
      })
      .catch(() => {
        message.channel.send('No replay received within the timeout. Operation canceled.');
      });
  } else if (command === 'autoreplay') {
    const word = args.join(" ");
    if (!word) {
      message.channel.send('Please provide a word to check for a replay.');
      return;
    }

    const replays = getReplays();
    if (replays[word]) {
      message.channel.send(`Replay for the word "${word}": ${replays[word]}`);
    }
  } else if (command === 'lr') {
    const replays = getReplays();
    const replayList = Object.keys(replays).map(word => `**الكلمة: ${word}, الرد: ${replays[word]}**`).join('\n');
    message.channel.send(replayList || 'There are no replays saved.');
  } else if (command === 'dr') {
    const wordToDelete = args.join(" ");
    if (!wordToDelete) {
      message.channel.send('Please provide a word to delete its replay.');
      return;
    }
    const replays = getReplays();
    if (replays[wordToDelete]) {
      delete replays[wordToDelete];
      fs.writeFile('./replays.json', JSON.stringify(replays), err => {
        if (err) {
          console.error('Error writing to replays.json:', err);
          sendErrorToChannel(err);
          return;
        }
        message.channel.send(`Replay for the word "${wordToDelete}" has been deleted.`);
      });
    } else {
      message.channel.send(`No replay found for the word "${wordToDelete}".`);
    }
  }
});

// Auto-reply with saved replays
client.on('message', message => {
  const replays = getReplays();
  const words = Object.keys(replays);
  for (const word of words) {
    if (message.content.toLowerCase().includes(word.toLowerCase())) {
      message.reply(replays[word]);
      break; // Stop after sending one replay
    }
  }
});

function saveReplay(word, replay) {
  const replays = getReplays();
  replays[word] = replay;
  fs.writeFile('./replays.json', JSON.stringify(replays), err => {
    if (err) console.error('Error writing to replays.json:', err);
  });
}

function getReplays() {
  try {
    return require("./replays.json");
  } catch (error) {
    console.error("Error reading replays.json:", error);
    return {};
  }
}
//
client.on('message', message => {
  if (message.author.id === '520774569855025152') 
  if (message.author.bot || message.channel.type !== 'text') return;

  const prefix = global.config.prefix;

  if (message.content.startsWith(`<@!${client.user.id}> setpx`)) {
      if (!global.config.allowed.includes(message.author.id)) {
          message.channel.send("You don't have permission to use this command.");
          return;
      }

      const args = message.content.slice(`<@!${client.user.id}> setpx`.length).trim().split(/ +/);
      const newPrefix = args[0];

      if (!newPrefix) {
          message.channel.send('Please provide a new prefix.');
          return;
      }

      global.config.prefix = newPrefix;
      fs.writeFile('./config.js', `module.exports = { token: "${global.config.token}", prefix: "${newPrefix}" };`, err => {
          if (err) {
              console.error('Error writing to config.js:', err);
              sendErrorToChannel(err);
              return;
          }
          message.channel.send(`Prefix has been updated to "${newPrefix}".`);
      });
      if (!message.content.startsWith(prefix)) return;

  // Rest of your command handling logic...
  }
});
  
// Command to block bot from specific text channels
client.on('message', message => {
  if (message.author.id === '520774569855025152') { // Replace 'YOUR_USER_ID_HERE' with your actual Discord user ID
    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    if (command === 'block') {
      const channelsToBlock = message.mentions.channels;
      if (!channelsToBlock.size) {
        message.channel.send('Please mention the text channels you want to block the bot from.');
        return;
      }

      channelsToBlock.forEach(channel => {
        // Store the blocked channel IDs in a configuration variable
        global.config.blockedChannels.push(channel.id);
      });

      // Save the blocked channels to a JSON file
      saveBlockedChannels();

      // Optionally, inform the user that the channels have been blocked
      message.channel.send('Bot has been blocked from the specified text channels.');
    } else if (command === 'unblock') {
      const channelsToUnblock = message.mentions.channels;
      if (!channelsToUnblock.size) {
        message.channel.send('Please mention the text channels you want to unblock the bot from.');
        return;
      }

      channelsToUnblock.forEach(channel => {
        // Remove the channel ID from the list of blocked channels
        const index = global.config.blockedChannels.indexOf(channel.id);
        if (index !== -1) {
          global.config.blockedChannels.splice(index, 1);
        }
      });

      // Save the blocked channels to a JSON file
      saveBlockedChannels();

      // Optionally, inform the user that the channels have been unblocked
      message.channel.send('Bot has been unblocked from the specified text channels.');
    }
  }
});

// Function to save blocked channels to a JSON file
function saveBlockedChannels() {
  fs.writeFile('./blocked_channels.json', JSON.stringify({ blockedChannels: global.config.blockedChannels }), (err) => {
    if (err) {
      console.error('Error writing to blocked_channels.json:', err);
      sendErrorToChannel(err);
      return;
    }
    console.log('Blocked channels saved successfully.');
  });
}
const stringFilePath = './strings.json'; // Path to your string.json file
const MAX_STRING_LENGTH = 200; // Adjust this value as needed
const allowedUserId = '520774569855025152';

// Command to list all replays in string.json
client.on('message', message => {
  const prefix = config.prefix;

  if (!message.content.startsWith(prefix) || message.author.id !== allowedUserId) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'ls') {
    try {
      const strings = getStrings();
      const stringEntries = Object.entries(strings);
      const pageSize = 10;
      let page = parseInt(args[0]) || 1;
      if (page < 1) page = 1;
      const totalPages = Math.ceil(stringEntries.length / pageSize);
      
      if (page > totalPages) {
        message.channel.send(`Page ${page} does not exist.`);
        return;
      }
      
      const startIdx = (page - 1) * pageSize;
      const endIdx = startIdx + pageSize;
      const pageStrings = stringEntries.slice(startIdx, endIdx);

      const stringList = pageStrings.map(([key, value]) => `**Key: ${key}, Value: ${value.slice(0, MAX_STRING_LENGTH)}**`).join('\n');
      message.channel.send(`Page ${page}/${totalPages}\n\n${stringList}`);
    } catch (error) {
      message.channel.send('An error occurred while listing strings.');
      console.error('Error listing strings:', error);
    }
  }
});


// Command to edit a specific replay in string.json
client.on('message', message => {
  const prefix = config.prefix;

  if (!message.content.startsWith(prefix) || message.author.id !== allowedUserId) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'ed') {
    const key = args[0];
    if (!key) {
      message.channel.send('Please provide a key to edit its string.');
      return;
    }

    const strings = getStrings();
    const currentValue = strings[key];

    if (!currentValue) {
      message.channel.send(`No string found for the key "${key}".`);
      return;
    }

    message.channel.send(`Please reply with the new value for the key "${key}" within 15 seconds.`);

    const filter = m => m.author.id === message.author.id;
    message.channel.awaitMessages({ filter, max: 1, time: 15000, errors: ['time'] })
      .then(collected => {
        const newValue = collected.first().content;
        strings[key] = newValue;
        fs.writeFile(stringFilePath, JSON.stringify(strings), err => {
          if (err) {
            console.error('Error writing to string.json:', err);
            sendErrorToChannel(err);
            return;
          }
          message.channel.send(`Value for the key "${key}" has been updated.`);
        });
      })
      .catch(() => {
        message.channel.send('No new value received within the timeout. Operation canceled.');
      });
  }
});

client.on('message', message => {
  if (!message.content.startsWith(prefix) || message.author.bot || message.channel.type !== 'text') return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (message.author.id !== allowedUserId) {
    message.channel.send("You don't have permission to use this command.");
    return;
  }

  if (command === 'lo') {
    const propertyName = args[0];
    if (!propertyName) {
      message.channel.send('Please provide a property name to edit in config.');
      return;
    }

    const loData = require('./lo.js');

    if (!loData.hasOwnProperty(propertyName)) {
      message.channel.send(`Property "${propertyName}" does not exist in config.`);
      return;
    }

    message.channel.send(`Please reply with the new value for the property "${propertyName}" within 15 seconds.`);

    const filter = m => m.author.id === message.author.id;
    message.channel.awaitMessages({ filter, max: 1, time: 15000, errors: ['time'] })
      .then(collected => {
        const newValue = collected.first().content;
        loData[propertyName] = newValue;
        fs.writeFile('./lo.js', `module.exports = ${JSON.stringify(loData, null, 2)}`, err => {
          if (err) {
            console.error('Error writing to lo.js:', err);
            message.channel.send('An error occurred while writing to lo.js. Please try again later.');
            return;
          }
          message.channel.send(`Property "${propertyName}" has been updated.`);
        });
      })
      .catch(() => {
        message.channel.send('No new value received within the timeout. Operation canceled.');
      });
  } else if (command === 'sh') {
    const loData = require('./lo.js');
    message.channel.send(`Contents of lo.js:\n\`\`\`json\n${JSON.stringify(loData, null, 2)}\n\`\`\``);
  }
});
// Function to read strings from string.json
function getStrings() {
  try {
    return require(stringFilePath);
  } catch (error) {
    console.error("Error reading string.json:", error);
    return {};
  }
}